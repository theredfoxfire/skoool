<?php
/**
* return string of asset dir
*/
function asset_url(){
   return base_url().'assets/';
}
