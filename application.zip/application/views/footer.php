<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<footer>
    <div class="footer-links">
        <a href="<?php echo base_url(); ?>home" class="footer-link">HOME</a>
        <a href="<?php echo base_url(); ?>about" class="footer-link">ABOUT</a>
        <a href="<?php echo base_url(); ?>contact" class="footer-link">CONTACT</a>
        <a href="http://sakola.co.id" class="copy-link">&copy; sakola.co.id</a>
    </div>
</footer>
</div>

</body>
<script src="<?php echo asset_url(); ?>js/jquery.min.js"></script>
<script src="<?php echo asset_url(); ?>js/bootstrap.min.js"></script>
<script>
$('#myarea').tooltip();
$('#myarea2').tooltip();
$('#myarea3').tooltip();
$('#myarea4').tooltip();
$('#myarea5').tooltip();
$('#myarea6').tooltip();
$('#myarea7').tooltip();
</script>
</html>
