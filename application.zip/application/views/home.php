<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div id="body" align="center">
	<p>

		<img src="<?php echo asset_url(); ?>images/building.png" class="img-home" usemap="#building" height="800" width="1000">
			<map name="building" id="building">
			  <area shape="rect" coords="450,50,650,150" href="<?php echo base_url(); ?>sportcenter"
			      title="Sport center" id="myarea" data-placement="right" data-toggle="modal" />
			  <area shape="rect" coords="390,130,460,220" href="<?php echo base_url(); ?>canteen"
  				title="Canteen" id="myarea2" data-placement="right" data-toggle="modal" />
			  <area shape="rect" coords="250,240,330,340" href="<?php echo base_url(); ?>library"
  				title="Library" id="myarea3" data-placement="right" data-toggle="modal" />
			  <area shape="rect" coords="150,330,230,420" href="<?php echo base_url(); ?>creative_house"
  				title="Creative House" id="myarea4" data-placement="right" data-toggle="modal" />
			  <area shape="rect" coords="230,450,280,550" href="<?php echo base_url(); ?>tempat_parkir"
  				title="Tempat Parkir" id="myarea5" data-placement="right" data-toggle="modal" />
			  <area shape="rect" coords="280,460,340,580" href="<?php echo base_url(); ?>tempat_parkir"
  				title="Tempat Parkir" id="myarea6" data-placement="right" data-toggle="modal" />
			  <area shape="rect" coords="330,540,380,580" href="<?php echo base_url(); ?>tempat_parkir"
  				title="Tempat Parkir" id="myarea7" data-placement="right" data-toggle="modal" />
			</map>
		</img>
	</p>
</div>
